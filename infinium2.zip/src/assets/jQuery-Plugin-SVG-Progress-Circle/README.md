# ProgressCircle
Pure CSS Animated SVG Circle Chart with jQuery Rendering

![Demo Image](https://rawgit.com/killia15/ProgressCircle/master/demo.png)
